from flask import Flask, render_template, jsonify
import mysql.connector
from jinja2 import Template
import requests
import random
from datetime import datetime, timedelta
import re
import os
import base64

# Define constants
API_URL = 'https://hub.vong.earth/webservice/rest/server.php'
ACCESS_TOKEN = 'd478810b234eb7682244b9f474c7468f'
HOST = 'localhost'
USER = 'moodle_user'
PASSWORD = 'Ashiv#3377'
DATABASE = 'moodle'

# Function to make a request to the Moodle API
def make_moodle_api_request(function, params=None):
    data = {
        'wstoken': ACCESS_TOKEN,
        'wsfunction': function,
        'moodlewsrestformat': 'json'
    }
    if params:
        data.update(params)

    response = requests.post(API_URL, data=data)
    return response.json()

# Function to generate random avatar color
def generate_random_color():
    color = '#' + ''.join(random.choices('0123456789ABCDEF', k=6))
    return color

# Connect to the database
try:
    connection = mysql.connector.connect(
        host=HOST,
        user=USER,
        password=PASSWORD,
        database=DATABASE
    )
    cursor = connection.cursor(dictionary=True)
except mysql.connector.Error as err:
    print("Error connecting to MySQL:", err)

# Retrieve student data from Moodle API and populate the students list
students = []

# Course IDs
course_ids = ['27', '28', '29']
for course_id in course_ids:
    users_response = make_moodle_api_request('core_enrol_get_enrolled_users', {'courseid': course_id})
    for user in users_response:
        user_id = user['id']
        fullname = user['fullname']
        email_address = user['email']

        # Fetch grades
        grades_response = make_moodle_api_request('gradereport_user_get_grades_table', {'userid': user_id, 'courseid': course_id})
        group_response = make_moodle_api_request('core_group_get_course_user_groups', {'courseid': course_id, 'userid': user_id})
        
        # Process grades
        group_names = [group['name'] for group in group_response.get('groups', [])]
        grades_total = sum(float(grade['grade']['content']) for grade in grades_response['tables'][0]['tabledata'] if 'grade' in grade)

        student = {
            'user_id': user_id,
            'fullname': fullname,
            'email_address': email_address,
            'grades_total': grades_total,
            'group_names': group_names,
            'avatar_color': generate_random_color()
        }
        students.append(student)

# Sort students based on grades in descending order
students.sort(key=lambda x: x['grades_total'], reverse=True)

# Retrieve top five students
top_five_students = students[:5]

# Retrieve special mentions data from the database
try:
    cursor.execute('SELECT * FROM special_mentions_data')
    rows = cursor.fetchall()
    result = []
    for row in rows:
        image_data = base64.b64encode(row['image']).decode("UTF-8")
        result.append({
            'id': row['id'],
            'name': row['name'],
            'image': image_data,
            'title': row['title'],
            'title_description': row['title_description'],
            'user_id': row['user_id']
        })
    special_mentions = result[::-1][:6]
except mysql.connector.Error as err:
    print("Error fetching data from MySQL:", err)

# Create Flask app
app = Flask(__name__)

# Render leaderboard HTML template
@app.route('/')
def leaderboard():
    return render_template('leaderboard.html', students=top_five_students, special_mentions=special_mentions)

if __name__ == '__main__':
    app.run(debug=True)
