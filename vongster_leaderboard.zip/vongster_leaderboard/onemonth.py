from flask import Flask, render_template, jsonify
import mysql.connector
from jinja2 import Template
import requests
import random
from datetime import datetime, timedelta
import re
import os
import base64

current_date = datetime.now()
# API URL
api_url = 'https://hub.vong.earth/webservice/rest/server.php'
directory = '/static/reports/'
if not os.path.exists(directory):
    os.makedirs(directory)
# Access token (replace 'your-access-token' with your actual access token)
access_token = 'd478810b234eb7682244b9f474c7468f'
date_chk=False
# Function to make a request to the Moodle API
def make_moodle_api_request(function, params=None):
    data = {
        'wstoken': access_token,
        'wsfunction': function,
        'moodlewsrestformat': 'json'
    }
    if params:
        data.update(params)

    response = requests.post(api_url, data=data)
    return response.json()

# Function to generate random avatar color
def generate_random_color():
    color = '#' + ''.join(random.choices('0123456789ABCDEF', k=6))
    return color

# Course ID (replace 'course-id' with the actual course ID)
students = []
students_data=[]
course_ids = ['27', '28', '29']



for course_id in course_ids:
  # Retrieve all enrolled users
  users_response = make_moodle_api_request('core_enrol_get_enrolled_users', {
      'courseid': course_id
  })

  # Process and collect grades for each user
  excluded_titles = ["Course total"]

  for user in users_response:
      user_id = user['id']
      fullname = user['fullname']
      email_address = user['email']

      # Retrieve grades table for the user
      grades_response = make_moodle_api_request('gradereport_user_get_grades_table', {
          'userid': user_id,
          'courseid': course_id
      })
      # Process and collect the grades for the user
      if 'tables' in grades_response and len(grades_response['tables']) > 0:
          grades_table = grades_response['tables'][0]['tabledata']
          grades_total = 0  # Initialize total grades for the user


          for grade_item in grades_table:
              if 'itemname' in grade_item and 'content' in grade_item['itemname']:
                  grade_item_name = grade_item['itemname']['content']
              else:
                  grade_item_name = 'N/A'
              grade = 'N/A'

              if 'grade' in grade_item:
                  grade = grade_item['grade']['content']

              if 'total' in grade_item_name:
                  pattern = r'\b\d{2}/\d{4}\b'

                  # Find all occurrences of the pattern in the HTML text
                  matches = re.findall(pattern, grade_item_name)

                  if matches:
                      title = matches[0]
                  else:
                      continue

                  date_format = "%m/%Y"
                  date = datetime.strptime(title, date_format)
                  one_month_ago = current_date - timedelta(days=90)
                  date_chk=False
                  if date < one_month_ago:
                      date_chk=True
              else:
                  continue
              if date_chk:
                  continue

              # Check if the grade is numeric
              if grade.replace('.', '', 1).isdigit():
                  grades_total += float(grade)

          student1 = {
              'user_id': user_id,
              'fullname': fullname,
              'email_address': email_address,
              'grades_total': grades_total,
              'avatar_color': generate_random_color()  # Generate random avatar color
          }
          students_data.append(student1)

students_dict = {}
for student_data in students_data:
    user_id = student_data['user_id']
    grades_total = student_data['grades_total']

    if user_id in students_dict:
        students_dict[user_id]['grades_total'] += grades_total
    else:
        student = {
            'user_id': user_id,
            'fullname': student_data['fullname'],
            'email_address': student_data['email_address'],
            'grades_total': grades_total,
            'avatar_color': generate_random_color()
        }
        students_dict[user_id] = student

students = list(students_dict.values())
# Sort students based on grades in descending order
students.sort(key=lambda x: x['grades_total'], reverse=True)

# Retrieve top three students
top_three_students = students[:3]

host = 'localhost'
user = 'moodle_user'
password = 'Ashiv#3377'
database = 'moodle'


try:
    # Connect to the database
    with mysql.connector.connect(
        host=host,
        user=user,
        password=password,
        database=database
    ) as conn:
        with conn.cursor(dictionary=True) as cursor:
            # Fetch all rows from the table
            print("Fetching all tables...")
            cursor.execute("SHOW TABLES")
            tables = cursor.fetchall()
            print("Tables in the database:")
            for table in tables:
                print(table['Tables_in_' + database])

            cursor.execute("DESCRIBE mdl_user")
            columns = cursor.fetchall()
            print("Columns in `mdl_user` table:")
            for email in columns:
                print(email)
            print("\nFetching `email` column from `mdl_user`...")
            cursor.execute("SELECT email FROM mdl_user")
            rows = cursor.fetchall()
            print("Email addresses in `mdl_user` table:")
            for row in rows:
                print(row['email'])

            select_query = 'SELECT * FROM special_mentions_data'
            cursor.execute(select_query)
            rows = cursor.fetchall()

            # Convert the rows to a list of dictionaries
            result = []

            for row in rows:
                image_data = base64.b64encode(row['image'])
                image_data = image_data.decode("UTF-8")
                result.append({
                    'id': row['id'],
                    'name': row['name'],
                    'image': image_data,
                    'title': row['title'],
                    'title_description': row['title_description'],
                    'user_id': row['user_id']
                })

            result = result[::-1][:6]


except mysql.connector.Error as err:
    print("error", err)

html_template = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>One Month Leaderboard</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="icon" href="uploads/number-1.png" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
</head>
<body>
    <nav class="navbar">
        <div class="nav-card">1 MONTH</div>
        <div class="nav-card active-nav-card"><a href="threemonth.html" style="text-decoration:none;">3 MONTH</a></div>
    </nav>
    <div class="trophy-design">
        <div style="position: absolute; top: -100px; z-index: 2;"><img src="trophy.png" alt=""></div>
        <div class="rectangles">
        <div><img src="Rectangleleft.png" alt=""></div>
        <div><img style="position:relative; top:10px" src="Rectangleright.png" alt=""></div>
        </div>
    </div>
    <div class="one-month-leaderboard"> 1 MONTH LEADERBOARD </div>
    <div class="yellow-line"><img src="Line1.png" alt=""></div>
    <div class="votm">VONGSTER OF THE MONTH</div>
    <div class="top-section">
        <div class="profile"></div>
        <div class="lines">
        <div><img src="Line2.png" alt=""></div>
        <div><img src="Line2.png" alt=""></div>
        </div>
    </div>
    <div class="profile-name">{{ top_three_students[0].fullname }}</div>
    <div class="profile-score">Score : <span>{{ top_three_students[0].grades_total|round(2) }}</span></div>
    <div>
        <div class="first">
            <div class="top-profile"><div class="top-profile-image"></div><div class="ring"><span class="rank">#1</span></div></div>
        </div>
        <div class="first-name">
            <div class="profile-name">{{ top_three_students[0].fullname }}</div>
            <div class="profile-score">Score : <span>{{ top_three_students[0].grades_total|round(2) }}</span></div>
        </div>
    </div>
    <div class="mid-section">
        <div>
            <div class="second">
                <div class="top-profile"><div class="top-profile-image"></div><div class="ring"><span class="rank">#2</span></div></div>
            </div>
            <div class="second-name">
                <div class="mid-profile-name">{{ top_three_students[1].fullname }}</div>
                <div class="mid-profile-score">Score : <span>{{ top_three_students[1].grades_total|round(2) }}</span></div>
            </div>
        </div>
        <div class="mid-section-list">
            {% for student in students[3:10] %}
                <div class="mid-section-list-elements">
                    <span class="mid-section-list-rank">{{loop.index + 3}}</span>
                    <img src="image13.jpg" class="mid-section-list-image" style="width:25px; height:25px; object-fit: scale-down;">
                    <span class="mid-section-list-name">{{ student.fullname }}</span>
                    <span class="mid-section-list-score">{{student.grades_total|round(2)}}</span>
                </div>
            {% endfor %}
        </div>
        <div>
            <div class="third">
                <div class="top-profile"><div class="top-profile-image"></div><div class="ring"><span class="rank">#3</span></div></div>
            </div>
            <div class="third-name">
                <div class="mid-profile-name">{{ top_three_students[2].fullname }}</div>
                <div class="mid-profile-score">Score : <span>{{ top_three_students[2].grades_total|round(2) }}</span></div>
            </div>
        </div>
    </div>
    <div>
        <div class="special-mentions-title">SPECIAL MENTIONS</div>
        <div class="special-mentions-card-container">
            {% for mention in mentions %}
            <div class="special-mentions-card">
                <div>
                    <div class="special-mentions-image"><img src="data:image/png;base64,{{ mention.image }}" style="border-radius:50%; height:150px; width:150px; border: 1.12px black solid;" alt=""></div>
                    <div class="special-mentions-name">{{ mention.name }}</div>
                </div>
                <div>
                    <div class="special-mentions-card-title">{{ mention.title }}</div>
                    <div class="special-mentions-card-description">{{ mention.title_description }}</div>
                </div>
            </div>
            {% endfor %}
        </div>
    </div>
</body>
</html>
'''

app = Flask(__name__)
template = Template(html_template)
data = {
    'top_three_students': top_three_students,
    'students': students,
    'mentions': result
}

rendered_html = template.render(data)

with open('/var/www/vongster_leaderboard/onemonth.html', 'w') as file:
    file.write(rendered_html)

print("Leaderboard generated successfully!")
