from flask import Flask, render_template, jsonify
import mysql.connector
from jinja2 import Template
import requests
import random
from datetime import datetime, timedelta
import re
import os
import base64

current_date = datetime.now()
# API URL
api_url = 'https://hub.vong.earth/webservice/rest/server.php'
directory = '/static/reports/'
if not os.path.exists(directory):
    os.makedirs(directory)
# Access token (replace 'your-access-token' with your actual access token)
access_token = 'd478810b234eb7682244b9f474c7468f'
date_chk=False
# Function to make a request to the Moodle API
def make_moodle_api_request(function, params=None):
    data = {
        'wstoken': access_token,
        'wsfunction': function,
        'moodlewsrestformat': 'json'
    }
    if params:
        data.update(params)

    response = requests.post(api_url, data=data)
    return response.json()

# Function to generate random avatar color
def generate_random_color():
    color = '#' + ''.join(random.choices('0123456789ABCDEF', k=6))
    return color

# Course ID (replace 'course-id' with the actual course ID)
students = []
students_data=[]
course_ids = ['27', '28', '29']



for course_id in course_ids:
  # Retrieve all enrolled users
  users_response = make_moodle_api_request('core_enrol_get_enrolled_users', {
      'courseid': course_id
  })

  # Process and collect grades for each user
  excluded_titles = ["Course total"]

  for user in users_response:
      user_id = user['id']
      fullname = user['fullname']
      email_address = user['email']

      # Retrieve grades table for the user
      grades_response = make_moodle_api_request('gradereport_user_get_grades_table', {
          'userid': user_id,
          'courseid': course_id
      })
      # Process and collect the grades for the user
      if 'tables' in grades_response and len(grades_response['tables']) > 0:
          grades_table = grades_response['tables'][0]['tabledata']
          grades_total = 0  # Initialize total grades for the user


          for grade_item in grades_table:
              if 'itemname' in grade_item and 'content' in grade_item['itemname']:
                  grade_item_name = grade_item['itemname']['content']
              else:
                  grade_item_name = 'N/A'
              grade = 'N/A'

              if 'grade' in grade_item:
                  grade = grade_item['grade']['content']

              if 'total' in grade_item_name:
                  pattern = r'\b\d{2}/\d{4}\b'

                  # Find all occurrences of the pattern in the HTML text
                  matches = re.findall(pattern, grade_item_name)

                  if matches:
                      title = matches[0]
                  else:
                      continue

                  date_format = "%m/%Y"
                  date = datetime.strptime(title, date_format)
                  year_ago = current_date - timedelta(days=365)
                  date_chk=False
                  if date < year_ago:
                      date_chk=True
              else:
                  continue
              if date_chk:
                  continue

              # Check if the grade is numeric
              if grade.replace('.', '', 1).isdigit():
                  grades_total += float(grade)

          student1 = {
              'user_id': user_id,
              'fullname': fullname,
              'email_address': email_address,
              'grades_total': grades_total,
              'avatar_color': generate_random_color()  # Generate random avatar color
          }
          students_data.append(student1)

students_dict = {}
for student_data in students_data:
    user_id = student_data['user_id']
    grades_total = student_data['grades_total']

    if user_id in students_dict:
        students_dict[user_id]['grades_total'] += grades_total
    else:
        student = {
            'user_id': user_id,
            'fullname': student_data['fullname'],
            'email_address': student_data['email_address'],
            'grades_total': grades_total,
            'avatar_color': generate_random_color()
        }
        students_dict[user_id] = student

students = list(students_dict.values())
# Sort students based on grades in descending order
students.sort(key=lambda x: x['grades_total'], reverse=True)

# Retrieve top three students
top_three_students = students[:3]


# MySQL connection details
host = 'localhost'
user = 'moodle_user'
password = 'Ashiv#3377'
database = 'moodle'

try:
    # Connect to the database
    with mysql.connector.connect(
        host=host,
        user=user,
        password=password,
        database=database
    ) as conn:
        with conn.cursor(dictionary=True) as cursor:
            # Fetch grades with house information
            select_query = '''
                SELECT u.fullname, u.email, u.grades_total, u.avatar_color, u.house_name
                FROM (
                    SELECT user_id, fullname, email, SUM(grade) AS grades_total, '{}' AS avatar_color, house_name
                    FROM mdl_user
                    LEFT JOIN mdl_grade_grades ON mdl_user.id = mdl_grade_grades.user_id
                    WHERE mdl_grade_grades.itemname != 'course total' AND grade IS NOT NULL
                    GROUP BY user_id
                ) AS u
                ORDER BY u.grades_total DESC
                LIMIT 10
            '''.format(generate_random_color())  # Assuming generate_random_color() generates a random color

            cursor.execute(select_query)
            rows = cursor.fetchall()

            # Prepare data for rendering
            students = []
            for row in rows:
                student = {
                    'fullname': row['fullname'],
                    'email': row['email'],
                    'grades_total': float(row['grades_total']),  # Convert to float if necessary
                    'avatar_color': row['avatar_color'],
                    'house_name': row['house_name']
                }
                students.append(student)

except mysql.connector.Error as err:
    print("MySQL Error:", err)

# Render the leaderboard template with data
app = Flask(__name__)

@app.route('/house')
def leaderboard():
    return render_template('house.html', students=students)

if __name__ == "__main__":
    app.run(host='127.0.0.1', port=5000, debug=True)
