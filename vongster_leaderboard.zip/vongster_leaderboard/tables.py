import mysql.connector
from mysql.connector import Error

def interact_with_database(host, user, password, database):
    connection = None
    cursor = None
    try:
        # Connect to the database
        connection = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )

        if connection.is_connected():
            print("Successfully connected to the database")
            cursor = connection.cursor(dictionary=True)

            while True:
                # Get query from the user
                query = input("\nEnter SQL query to execute (or type 'exit' to quit): ")
                
                if query.lower() == 'exit':
                    break

                try:
                    cursor.execute(query)

                    if query.strip().lower().startswith('select'):
                        rows = cursor.fetchall()
                        if rows:
                            for row in rows:
                                print(row)
                        else:
                            print("No results found")
                    
                    else:
                        print("Query executed successfully")
                        connection.commit()

                except Error as e:
                    print(f"Error executing query: {e}")
                
                # Fetch any remaining results to avoid 'Unread result found' error
                while True:
                    try:
                        cursor.fetchall()  # Clear any remaining results
                    except Error as e:
                        if str(e).startswith('MySQL server has gone away'):
                            break
                        if str(e).startswith('Lost connection'):
                            break
                        print(f"Error clearing results: {e}")
                        break

    except Error as e:
        print(f"Error: {e}")

    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()
            print("\nDatabase connection closed")

# Replace with your database credentials
host = 'localhost'
user = 'moodle_user'
password = 'Ashiv#3377'
database = 'moodle'

interact_with_database(host, user, password, database)
