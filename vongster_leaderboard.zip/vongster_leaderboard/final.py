from flask import Flask,render_template,jsonify
import mysql.connector
from jinja2 import Template
import requests
import random
from datetime import datetime, timedelta
import re
import os
import base64


current_date = datetime.now()

# API URL
api_url = 'https://hub.vong.earth/webservice/rest/server.php'

# Access token (replace 'your-access-token' with your actual access token)
access_token = 'd478810b234eb7682244b9f474c7468f'

# Function to make a request to the Moodle API
def make_moodle_api_request(function, params=None):
    data = {
        'wstoken': access_token,
        'wsfunction': function,
        'moodlewsrestformat': 'json'
    }
    if params:
        data.update(params)

    response = requests.post(api_url, data=data)
    return response.json()

# Function to generate random avatar color
def generate_random_color():
    color = '#' + ''.join(random.choices('0123456789ABCDEF', k=6))
    return color

# Retrieve student data from Moodle API and populate the students list
students = []

# Course ID (replace 'course-id' with the actual course ID)
course_ids = ['27', '28', '29']
for course_id in course_ids:
    # Retrieve all enrolled users
    users_response = make_moodle_api_request('core_enrol_get_enrolled_users', {
        'courseid': course_id
    })

    # Process and collect grades for each user
    for user in users_response:
        user_id = user['id']
        fullname = user['fullname']
        email_address = user['email']

        # Retrieve grades table for the user
        grades_response = make_moodle_api_request('gradereport_user_get_grades_table', {
            'userid': user_id,
            'courseid': course_id
        })

        group_response = make_moodle_api_request('core_group_get_course_user_groups', {
            'courseid': course_id,
            'userid': user_id
        })

        group_names = []
        if 'groups' in group_response:
            group_names = [group['name'] for group in group_response['groups']]

        if 'tables' in grades_response and len(grades_response['tables']) > 0:
            grades_table = grades_response['tables'][0]['tabledata']
            grades_total = 0

            for grade_item in grades_table:
                if 'itemname' in grade_item and 'content' in grade_item['itemname']:
                    grade_item_name = grade_item['itemname']['content']
                else:
                    grade_item_name = 'N/A'

                grade = 'N/A'

                if 'grade' in grade_item:
                    grade = grade_item['grade']['content']

                if 'total' in grade_item_name:
                    pattern = r'\b\d{2}/\d{4}\b'

                    matches = re.findall(pattern, grade_item_name)

                    if matches:
                        title = matches[0]
                    else:
                        continue

                    date_format = "%m/%Y"
                    date = datetime.strptime(title, date_format)
                    three_months_ago = current_date - timedelta(days=100)
                    if date < three_months_ago:
                        continue

                if grade.replace('.', '', 1).isdigit():
                    grades_total += float(grade)

            student = {
                'user_id': user_id,
                'fullname': fullname,
                'email_address': email_address,
                'grades_total': grades_total,
                'group_names': group_names,
                'avatar_color': generate_random_color()
            }
            students.append(student)

# Sort students based on grades in descending order
students.sort(key=lambda x: x['grades_total'], reverse=True)

# Retrieve top five students
top_five_students = students[:5]

host = 'localhost'
user = 'moodle_user'
password = 'Ashiv#3377'
database = 'moodle'


try:
        # Connect to the database
        with mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        ) as conn:
            with conn.cursor(dictionary=True) as cursor:
                # Fetch all rows from the table
                select_query = 'SELECT * FROM special_mentions_data'
                cursor.execute(select_query)
                rows = cursor.fetchall()

                # Convert the rows to a list of dictionaries
                result = []
                for row in rows:
                    image_data = base64.b64encode(row['image'])
                    image_data = image_data.decode("UTF-8")
                    result.append({
                        'id': row['id'],
                        'name': row['name'],
                        'image': image_data,
                        'title': row['title'],
                        'title_description': row['title_description'],
                        'user_id': row['user_id']
                    })

                result = result[::-1][:6]

except mysql.connector.Error as err:
    print("error", err)


# Load the leaderboard HTML template
html_template = '''
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Leaderboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/0a56e63d65.js" crossorigin="anonymous"></script>
    <!-- CSS styles -->
    <style>
        body {
            background-color: #f5f9fa;
        }
        .navbar {
            background-color: #009688;
        }
        .navbar-light .navbar-nav .nav-link {
            color: white;
            font-size: larger;
            margin-left: 20px;
        }
        .navbar-light .navbar-nav .nav-link:hover {
            color: #fff;
        }
        .leaderboard-container {
            text-align: center;
            padding: 20px;
        }
        .leaderboard-title {
            color: #009688;
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .leaderboard-subtitle {
            color: #009688;
            font-size: 24px;
            margin-bottom: 30px;
        }
        .achievers-title {
            background-color: #009688;
            color: white;
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            padding: 8px 0;
            border-radius: 10px;
            margin-top: 30px;
        }
        .achievers-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 20px;
        }
        .achievers-card {
            background-color: #ffffff;
            border: none;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.1);
            margin: 20px;
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .achievers-card:hover {
            transform: translateY(-10px);
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.2);
        }
        .achievers-name {
            font-weight: bold;
            margin-bottom: 5px;
        }
        .achievers-score {
            font-size: 18px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"><img src="https://vong.orionsquare.org/wp-content/uploads/2022/01/Vong-new-Logo-60.jpg" alt="Logo"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link" aria-current="page" href="lifelong.html" id="lifetime" onclick="changeColor('lifetime')">Lifetime</a>
                    <a class="nav-link" aria-current="page" href="threemonth.html" id="threemonth" onclick="changeColor('Three month')">Three month</a>
                    <a class="nav-link" href="#" id="groupboard" onclick="changeColor('groupboard')">House</a>
                </div>
            </div>
        </div>
    </nav>
    <div class="leaderboard-container">
        <h1 class="leaderboard-title">Leaderboard</h1>
        <h3 class="leaderboard-subtitle">GROUP LEADER BOARD</h3>
        <div class="top-group-container">
            <div class="achievers-container">
                {% for student in students[:5] %}
                <div class="achievers-card">
                    <div class="achievers-name">{{ student.fullname }}</div>
                    <div class="achievers-score">{{ student.grades_total|round(2) }}</div>
                </div>
                {% endfor %}
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
'''

# Create the Jinja2 template object
template = Template(html_template)

# Create the data object for rendering the template
data = {
    'students': top_five_students
}

# Render the HTML using the template and data
rendered_html = template.render(data)

# Save the HTML code to a file
with open('leaderboard.html', 'w') as file:
    file.write(rendered_html)

print("Leaderboard generated successfully!")
