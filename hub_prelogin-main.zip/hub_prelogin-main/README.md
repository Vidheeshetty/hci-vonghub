HUB RELEASE - Version 2.0

Release Date: 30/01/2024

New Features:

 Pre-Login Page

Header:
 A visually appealing header featuring four slider images.
 One main page slider and three community sliders, each using vibrant 3D illustrations.
Page colors dynamically change with each slider, reflecting the respective community colors.
Latest Event:
Fetches data from the Moodle calendar plugin.
Displays event details, including title, description, date, and poster image.
Calendar view for a convenient overview of upcoming events.
Leaderboard:
 Features a leaderboard based on forum activity grade.
 Displays Vongster names, scores, and ranks.
Includes lifetime, three-month, and house leaderboards.
Profile pictures, award titles, and descriptions for each special mention.

Photo Gallery:
Showcases completed activities in an interactive slider format.
Thumbnails of forum events for a quick and engaging photo gallery experience.


Thank you!!
